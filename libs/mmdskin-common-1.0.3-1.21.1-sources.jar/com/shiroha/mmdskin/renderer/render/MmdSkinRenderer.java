package com.shiroha.mmdskin.renderer.render;

import com.shiroha.mmdskin.MmdSkin;
import com.shiroha.mmdskin.renderer.core.RenderContext;
import com.shiroha.mmdskin.renderer.core.RenderParams;
import com.shiroha.mmdskin.renderer.model.MMDModelManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * MMD 自定义实体渲染器 (SRP - 单一职责原则)
 * 
 * 仅负责渲染流程编排，动画状态解析委托给 {@link EntityAnimationResolver}。
 */
public class MmdSkinRenderer<T extends Entity> extends EntityRenderer<T> {
    
    private static final ResourceLocation PLACEHOLDER_TEXTURE = 
            ResourceLocation.fromNamespaceAndPath(MmdSkin.MOD_ID, "textures/entity/placeholder.png");
    
    protected final String modelName;

    public MmdSkinRenderer(EntityRendererProvider.Context renderManager, String entityName) {
        super(renderManager);
        this.modelName = entityName.replace(':', '.');
    }

    @Override
    public void render(T entityIn, float entityYaw, float tickDelta, PoseStack matrixStackIn, 
                       MultiBufferSource bufferIn, int packedLightIn) {
        super.render(entityIn, entityYaw, tickDelta, matrixStackIn, bufferIn, packedLightIn);
        
        MMDModelManager.Model model = MMDModelManager.GetModel(modelName, entityIn.getStringUUID());
        if (model == null) return;
        
        model.loadModelProperties(false);
        float[] size = parseModelSize(model);
        
        // 委托动画状态解析（OCP）
        RenderParams params = new RenderParams();
        EntityAnimationResolver.resolve(entityIn, model, entityYaw, tickDelta, params);
        
        matrixStackIn.pushPose();
        
        // 幼体缩放
        if (entityIn instanceof LivingEntity living && living.isBaby()) {
            matrixStackIn.scale(0.5f, 0.5f, 0.5f);
        }
        
        // 根据场景选择渲染方式（使用 InventoryRenderHelper 替代栈帧检测）
        if (InventoryRenderHelper.isInventoryScreen()) {
            renderInInventory(entityIn, model, entityYaw, tickDelta, matrixStackIn, packedLightIn, size);
        } else {
            matrixStackIn.scale(size[0], size[0], size[0]);
            RenderSystem.setShader(GameRenderer::getRendertypeEntityCutoutNoCullShader);
            model.model.render(entityIn, params.bodyYaw, params.bodyPitch, params.translation, 
                             tickDelta, matrixStackIn, packedLightIn, RenderContext.WORLD);
        }
        
        matrixStackIn.popPose();
    }
    
    /**
     * 库存界面渲染
     */
    private void renderInInventory(T entityIn, MMDModelManager.Model model, float entityYaw,
                                    float tickDelta, PoseStack matrixStack, int packedLight, float[] size) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen == null) return;
        
        // MC 1.21.1: 使用传入的 PoseStack 进行渲染（移除 RenderSystem.getModelViewStack()）
        matrixStack.pushPose();
        matrixStack.scale(20.0f, 20.0f, -20.0f);
        matrixStack.scale(size[1], size[1], size[1]);
        
        Quaternionf rotation = new Quaternionf().rotateZ((float) Math.PI);
        rotation.mul(new Quaternionf().rotateX(-entityIn.getXRot() * ((float) Math.PI / 180F)));
        rotation.mul(new Quaternionf().rotateY(-entityIn.getYRot() * ((float) Math.PI / 180F)));
        matrixStack.mulPose(rotation);
        
        RenderSystem.setShader(GameRenderer::getRendertypeEntityCutoutNoCullShader);
        model.model.render(entityIn, entityYaw, 0.0f, new Vector3f(0.0f), 
                          tickDelta, matrixStack, packedLight, RenderContext.INVENTORY);
        matrixStack.popPose();
    }

    /**
     * 安全解析模型尺寸属性
     */
    private static float[] parseModelSize(MMDModelManager.Model model) {
        float[] size = new float[2];
        size[0] = parseFloat(model, "size", 1.0f);
        size[1] = parseFloat(model, "size_in_inventory", 1.0f);
        return size;
    }
    
    private static float parseFloat(MMDModelManager.Model model, String key, float defaultValue) {
        String value = model.properties.getProperty(key);
        if (value == null) return defaultValue;
        try {
            return Float.parseFloat(value);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return PLACEHOLDER_TEXTURE;
    }
}
